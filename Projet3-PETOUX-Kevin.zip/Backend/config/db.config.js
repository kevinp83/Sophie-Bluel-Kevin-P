module.exports = {
	dialect: "sqlite",
	storage: './database.sqlite'
};
